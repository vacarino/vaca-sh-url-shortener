<?php
/**
 * Vaca.Sh Laravel Installer
 * Standalone installation script for shared hosting environments
 * Compatible with WPX.net hosting (no exec/shell_exec dependency)
 */

// Security configuration
define('INSTALL_SECRET', 'setup123'); // Change this for security
define('REQUIRED_PHP_VERSION', '8.1.0');

// Check for install secret (comment out to disable)
if (!isset($_GET['code']) || $_GET['code'] !== INSTALL_SECRET) {
    http_response_code(403);
    die('Access denied. Please provide the correct installation code.');
}

// Initialize variables
$errors = [];
$success = [];
$step = $_GET['step'] ?? 'check';

// Helper functions
function checkPrerequisites() {
    global $errors;
    
    // Check PHP version
    if (version_compare(PHP_VERSION, REQUIRED_PHP_VERSION, '<')) {
        $errors[] = "PHP version " . REQUIRED_PHP_VERSION . " or higher is required. Current version: " . PHP_VERSION;
    }
    
    // Check required extensions
    $required_extensions = ['pdo', 'mbstring', 'openssl', 'tokenizer', 'ctype', 'json'];
    foreach ($required_extensions as $ext) {
        if (!extension_loaded($ext)) {
            $errors[] = "PHP extension '{$ext}' is required but not installed.";
        }
    }
    
    // Check writable directories
    $writable_dirs = ['storage', 'bootstrap/cache'];
    foreach ($writable_dirs as $dir) {
        if (!is_dir($dir)) {
            $errors[] = "Directory '{$dir}' does not exist.";
        } elseif (!is_writable($dir)) {
            $errors[] = "Directory '{$dir}' is not writable.";
        }
    }
    
    // Check if .env.example.production exists
    if (!file_exists('.env.example.production')) {
        $errors[] = ".env.example.production file not found. Please ensure all Laravel files are uploaded.";
    }
    
    // Check if composer dependencies are installed
    if (!is_dir('vendor') || !file_exists('vendor/autoload.php')) {
        $errors[] = "Composer dependencies not found. Please ensure vendor/ directory is uploaded.";
    }
    
    return empty($errors);
}

function isAlreadyInstalled() {
    return file_exists('.env') && !empty(getEnvValue('.env', 'APP_KEY'));
}

function getEnvValue($file, $key) {
    if (!file_exists($file)) return null;
    
    $content = file_get_contents($file);
    $lines = explode("\n", $content);
    
    foreach ($lines as $line) {
        if (strpos($line, $key . '=') === 0) {
            return trim(substr($line, strlen($key) + 1), '"\'');
        }
    }
    
    return null;
}

function validateInput($data) {
    global $errors;
    
    if (empty($data['app_url'])) {
        $errors[] = "APP_URL is required.";
    } elseif (!filter_var($data['app_url'], FILTER_VALIDATE_URL)) {
        $errors[] = "APP_URL must be a valid URL.";
    }
    
    if (empty($data['db_host'])) {
        $errors[] = "Database host is required.";
    }
    
    if (empty($data['db_database'])) {
        $errors[] = "Database name is required.";
    }
    
    if (empty($data['db_username'])) {
        $errors[] = "Database username is required.";
    }
    
    if (empty($data['db_password'])) {
        $errors[] = "Database password is required.";
    }
    
    if (!empty($data['db_port']) && !is_numeric($data['db_port'])) {
        $errors[] = "Database port must be a number.";
    }
    
    return empty($errors);
}

function createEnvFile($data) {
    // Read .env.example.production
    $env_example = file_get_contents('.env.example.production');
    
    if (!$env_example) {
        throw new Exception('Could not read .env.example.production file');
    }
    
    // Replace placeholders
    $replacements = [
        'APP_NAME=Vaca.Sh' => 'APP_NAME="' . ($data['app_name'] ?: 'Vaca.Sh') . '"',
        'APP_ENV=production' => 'APP_ENV=production',
        'APP_DEBUG=false' => 'APP_DEBUG=false',
        'APP_URL=https://vaca.sh' => 'APP_URL=' . rtrim($data['app_url'], '/'),
        
        'DB_CONNECTION=mysql' => 'DB_CONNECTION=mysql',
        'DB_HOST=' => 'DB_HOST=' . $data['db_host'],
        'DB_PORT=3306' => 'DB_PORT=' . ($data['db_port'] ?: '3306'),
        'DB_DATABASE=' => 'DB_DATABASE=' . $data['db_database'],
        'DB_USERNAME=' => 'DB_USERNAME=' . $data['db_username'],
        'DB_PASSWORD=' => 'DB_PASSWORD=' . $data['db_password'],
    ];
    
    foreach ($replacements as $search => $replace) {
        $env_example = str_replace($search, $replace, $env_example);
    }
    
    // Save .env file
    if (!file_put_contents('.env', $env_example)) {
        throw new Exception('Could not create .env file. Check permissions.');
    }
    
    return true;
}

function generateAppKey() {
    // Generate a secure random key for Laravel
    $key = 'base64:' . base64_encode(random_bytes(32));
    
    // Read .env file
    $env_content = file_get_contents('.env');
    if ($env_content === false) {
        return false;
    }
    
    // Replace empty APP_KEY with generated key
    $env_content = str_replace('APP_KEY=', 'APP_KEY=' . $key, $env_content);
    
    // Write back to file
    return file_put_contents('.env', $env_content) !== false;
}

function setPermissions() {
    $results = [];
    
    $directories = ['storage', 'bootstrap/cache'];
    
    foreach ($directories as $dir) {
        if (function_exists('chmod')) {
            $success = chmod($dir, 0775);
            $results[] = [
                'directory' => $dir,
                'success' => $success,
                'message' => $success ? "Permissions set successfully" : "Failed to set permissions"
            ];
        } else {
            $results[] = [
                'directory' => $dir,
                'success' => false,
                'message' => "chmod() function not available"
            ];
        }
    }
    
    return $results;
}

function testDatabaseConnection($host, $port, $database, $username, $password) {
    try {
        $dsn = "mysql:host=$host;port=$port;dbname=$database;charset=utf8mb4";
        $pdo = new PDO($dsn, $username, $password, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        return ['success' => true, 'message' => 'Database connection successful'];
    } catch (PDOException $e) {
        return ['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()];
    }
}

function canRunArtisanCommands() {
    return function_exists('exec') || function_exists('shell_exec');
}

function getManualInstructions() {
    return [
        'Since exec() and shell_exec() functions are disabled on this server, you will need to run the following commands manually through your hosting control panel or SSH if available:',
        '',
        '1. Generate application key:',
        '   php artisan key:generate --force',
        '',
        '2. Run database migrations:',
        '   php artisan migrate --force',
        '',
        '3. Cache configuration (optional):',
        '   php artisan config:cache',
        '   php artisan route:cache',
        '   php artisan view:cache',
        '',
        '4. Set directory permissions to 775:',
        '   chmod -R 775 storage/',
        '   chmod -R 775 bootstrap/cache/',
        '',
        'After running these commands, your Vaca.Sh installation will be complete!'
    ];
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'delete_installer') {
        if (unlink(__FILE__)) {
            header('Location: /login');
            exit;
        } else {
            $errors[] = "Could not delete installer file. Please remove it manually.";
        }
    } elseif (isset($_POST['action']) && $_POST['action'] === 'install') {
        if (validateInput($_POST)) {
            // Test database connection first
            $db_test = testDatabaseConnection($_POST['db_host'], $_POST['db_port'] ?: '3306', $_POST['db_database'], $_POST['db_username'], $_POST['db_password']);
            
            if (!$db_test['success']) {
                $errors[] = $db_test['message'];
            } else {
                try {
                    // Create .env file
                    createEnvFile($_POST);
                    
                    // Generate APP_KEY
                    if (!generateAppKey()) {
                        $errors[] = "Failed to generate application key.";
                    } else {
                        // Set permissions
                        $permission_results = setPermissions();
                        
                        // Check if we can run artisan commands
                        $can_run_commands = canRunArtisanCommands();
                        
                        $step = 'success';
                    }
                    
                } catch (Exception $e) {
                    $errors[] = "Installation failed: " . $e->getMessage();
                }
            }
        }
    }
}

// Check prerequisites on first load
if ($step === 'check') {
    if (isAlreadyInstalled()) {
        $step = 'already_installed';
    } elseif (!checkPrerequisites()) {
        $step = 'prerequisites_failed';
    } else {
        $step = 'install_form';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vaca.Sh Installer</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#3B82F6',
                        secondary: '#8B5CF6'
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-gradient-to-br from-blue-50 via-white to-purple-50 min-h-screen">
    <div class="container mx-auto px-4 py-8 max-w-4xl">
        <!-- Header -->
        <div class="text-center mb-8">
            <div class="flex justify-center mb-4">
                <div class="flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl">
                    <svg class="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"></path>
                    </svg>
                </div>
            </div>
            <h1 class="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Welcome to Vaca.Sh Installer
            </h1>
            <p class="text-gray-600 mt-2">Set up your URL shortener in just a few steps</p>
        </div>

        <?php if (!empty($errors)): ?>
        <div class="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <div class="flex">
                <svg class="w-5 h-5 text-red-400 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path>
                </svg>
                <div class="ml-3">
                    <h3 class="text-sm font-medium text-red-800">Installation Error<?php echo count($errors) > 1 ? 's' : ''; ?></h3>
                    <div class="mt-2 text-sm text-red-700">
                        <ul class="list-disc pl-5 space-y-1">
                            <?php foreach ($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($step === 'prerequisites_failed'): ?>
        <div class="bg-white rounded-lg shadow-lg p-8">
            <h2 class="text-2xl font-bold text-red-600 mb-4">Prerequisites Check Failed</h2>
            <p class="text-gray-600 mb-6">Please fix the following issues before proceeding:</p>
            
            <div class="text-center">
                <a href="?code=<?php echo INSTALL_SECRET; ?>" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200">
                    Check Again
                </a>
            </div>
        </div>

        <?php elseif ($step === 'already_installed'): ?>
        <div class="bg-white rounded-lg shadow-lg p-8 text-center">
            <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg class="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                </svg>
            </div>
            <h2 class="text-2xl font-bold text-gray-900 mb-4">Already Installed</h2>
            <p class="text-gray-600 mb-6">Vaca.Sh is already installed on this server.</p>
            
            <div class="space-x-4">
                <a href="/login" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200">
                    Go to Login
                </a>
                <form method="POST" class="inline-block">
                    <input type="hidden" name="action" value="delete_installer">
                    <button type="submit" class="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200">
                        Delete Installer
                    </button>
                </form>
            </div>
        </div>

        <?php elseif ($step === 'install_form'): ?>
        <div class="bg-white rounded-lg shadow-lg p-8">
            <h2 class="text-2xl font-bold text-gray-900 mb-6">Installation Configuration</h2>
            
            <form method="POST" class="space-y-6">
                <input type="hidden" name="action" value="install">
                
                <!-- Application Settings -->
                <div class="border-b border-gray-200 pb-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Application Settings</h3>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="app_name" class="block text-sm font-medium text-gray-700 mb-2">Application Name</label>
                            <input type="text" id="app_name" name="app_name" value="<?php echo htmlspecialchars($_POST['app_name'] ?? 'Vaca.Sh'); ?>" 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500">
                        </div>
                        
                        <div>
                            <label for="app_url" class="block text-sm font-medium text-gray-700 mb-2">Application URL <span class="text-red-500">*</span></label>
                            <input type="url" id="app_url" name="app_url" value="<?php echo htmlspecialchars($_POST['app_url'] ?? 'https://vaca.sh'); ?>" required
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                                   placeholder="https://your-domain.com">
                        </div>
                    </div>
                </div>
                
                <!-- Database Settings -->
                <div>
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Database Settings</h3>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="db_host" class="block text-sm font-medium text-gray-700 mb-2">Database Host <span class="text-red-500">*</span></label>
                            <input type="text" id="db_host" name="db_host" value="<?php echo htmlspecialchars($_POST['db_host'] ?? 'localhost'); ?>" required
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                                   placeholder="localhost or IP address">
                        </div>
                        
                        <div>
                            <label for="db_port" class="block text-sm font-medium text-gray-700 mb-2">Database Port</label>
                            <input type="number" id="db_port" name="db_port" value="<?php echo htmlspecialchars($_POST['db_port'] ?? '3306'); ?>"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                                   placeholder="3306">
                        </div>
                        
                        <div>
                            <label for="db_database" class="block text-sm font-medium text-gray-700 mb-2">Database Name <span class="text-red-500">*</span></label>
                            <input type="text" id="db_database" name="db_database" value="<?php echo htmlspecialchars($_POST['db_database'] ?? ''); ?>" required
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                                   placeholder="vaca_sh">
                        </div>
                        
                        <div>
                            <label for="db_username" class="block text-sm font-medium text-gray-700 mb-2">Database Username <span class="text-red-500">*</span></label>
                            <input type="text" id="db_username" name="db_username" value="<?php echo htmlspecialchars($_POST['db_username'] ?? ''); ?>" required
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                                   placeholder="Database username">
                        </div>
                        
                        <div class="md:col-span-2">
                            <label for="db_password" class="block text-sm font-medium text-gray-700 mb-2">Database Password <span class="text-red-500">*</span></label>
                            <input type="password" id="db_password" name="db_password" value="<?php echo htmlspecialchars($_POST['db_password'] ?? ''); ?>" required
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                                   placeholder="Database password">
                        </div>
                    </div>
                </div>
                
                <div class="pt-6">
                    <button type="submit" class="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-3 rounded-lg font-medium transition-all duration-200 transform hover:scale-105">
                        Install Vaca.Sh
                    </button>
                </div>
            </form>
        </div>

        <?php elseif ($step === 'success'): ?>
        <div class="bg-white rounded-lg shadow-lg p-8">
            <div class="text-center mb-8">
                <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg class="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                </div>
                <h2 class="text-3xl font-bold text-gray-900 mb-4">Installation Successful!</h2>
                <p class="text-gray-600 mb-6">Your .env file has been created and application key generated.</p>
            </div>
            
            <?php if (!$can_run_commands): ?>
            <!-- Manual Instructions -->
            <div class="mb-8 p-6 bg-yellow-50 border border-yellow-200 rounded-lg">
                <h3 class="text-lg font-medium text-yellow-800 mb-4">
                    <svg class="w-5 h-5 inline mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"></path>
                    </svg>
                    Additional Setup Required
                </h3>
                <div class="text-sm text-yellow-700 space-y-2">
                    <?php foreach (getManualInstructions() as $instruction): ?>
                        <?php if (empty($instruction)): ?>
                            <br>
                        <?php else: ?>
                            <p><?php echo htmlspecialchars($instruction); ?></p>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Permission Results -->
            <?php if (isset($permission_results)): ?>
            <div class="mb-8">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Directory Permissions</h3>
                <div class="space-y-2">
                    <?php foreach ($permission_results as $result): ?>
                    <div class="flex items-center justify-between bg-gray-50 rounded-lg p-3">
                        <span class="font-mono text-sm"><?php echo htmlspecialchars($result['directory']); ?></span>
                        <div class="flex items-center">
                            <?php if ($result['success']): ?>
                                <svg class="w-4 h-4 text-green-500 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                                </svg>
                            <?php else: ?>
                                <svg class="w-4 h-4 text-red-500 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path>
                                </svg>
                            <?php endif; ?>
                            <span class="text-sm text-gray-600"><?php echo htmlspecialchars($result['message']); ?></span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Next Steps -->
            <div class="text-center space-y-4">
                <a href="/login" class="inline-block bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3 rounded-lg font-medium transition-all duration-200 transform hover:scale-105">
                    Go to Login Page
                </a>
                
                <form method="POST" class="inline-block ml-4">
                    <input type="hidden" name="action" value="delete_installer">
                    <button type="submit" class="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200">
                        Delete Install Script
                    </button>
                </form>
            </div>
            
            <div class="mt-8 p-4 bg-blue-50 rounded-lg">
                <h4 class="font-medium text-blue-900 mb-2">Important Security Note:</h4>
                <p class="text-sm text-blue-800">
                    For security reasons, please delete this install.php file after installation is complete. 
                    You can also manually set directory permissions using your hosting control panel if the automatic setup failed.
                </p>
            </div>
            
            <div class="mt-4 p-4 bg-green-50 rounded-lg">
                <h4 class="font-medium text-green-900 mb-2">Default Admin Account:</h4>
                <p class="text-sm text-green-800">
                    Login with: <strong>admin@vaca.sh</strong> / <strong>password</strong><br>
                    Please change these credentials immediately after logging in.
                </p>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Footer -->
        <div class="text-center mt-8 text-gray-500 text-sm">
            <p>Vaca.Sh URL Shortener &copy; <?php echo date('Y'); ?> | WPX.net Compatible</p>
        </div>
    </div>
</body>
</html> 